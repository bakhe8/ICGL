# Archived script
# Original location: scripts/run_all_windows.ps1

# ...existing code...