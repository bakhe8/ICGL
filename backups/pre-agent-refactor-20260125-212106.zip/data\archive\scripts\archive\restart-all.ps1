# Archived script
# Original location: scripts/restart-all.ps1

# ...existing code...