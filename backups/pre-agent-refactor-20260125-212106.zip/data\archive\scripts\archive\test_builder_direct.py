# Archived script
# Original location: ./test_builder_direct.py

# ...existing code...