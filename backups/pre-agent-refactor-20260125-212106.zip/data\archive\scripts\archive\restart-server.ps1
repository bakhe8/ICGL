# Archived script
# Original location: scripts/restart-server.ps1

# ...existing code...