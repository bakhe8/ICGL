# Archived script
# Original location: scripts/quick-restart.ps1

# ...existing code...