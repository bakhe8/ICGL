# Archived script
# Original location: ./test_reg.py

# ...existing code...