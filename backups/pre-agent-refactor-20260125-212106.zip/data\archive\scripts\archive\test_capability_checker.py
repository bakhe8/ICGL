# Archived script
# Original location: ./test_capability_checker.py

# ...existing code...