(Extended Mind System – Master Technical Document)
1. الرؤية والهوية الفلسفية
1.1 جوهر النظام
ليس أداة لتوليد الشيفرة، بل بيئة عمل مستقلة لإدارة التفكير البرمجي.

يعمل كـ عقل ممتد للمستخدم، يحول الأهداف والرؤى إلى قرارات برمجية مدروسة.

يحافظ على السيادة الكاملة للإنسان (المدير) مع تمكين الوكلاء المتخصصين من الملاحظة والتحليل.

1.2 الغاية النهائية
تحقيق النمو الواعي عبر تحويل كل سطر برمجي إلى قرار موثق الأسباب.

بناء ذاكرة مؤسسية شخصية تراكم المعرفة وتطور منهجية التفكير.

منح المبتكر تحكمًا كاملاً في رحلة بناء البرمجيات على المدى الطويل.

1.3 الهوية الفلسفية
النظام هو "بيئة تفكير تقنية" مصممة لتكون عقلاً ممتداً للمستخدم.

الغرض منه ليس "الأتمتة" بل "الوعي".

يعمل النظام كوعاء يحتمل الفكر البشري بكل تعقيداته (الغموض، التردد، اللعب) قبل تحويله إلى كود أو قرار صلب.

2. الطبقة الإدراكية (Cognitive Layer)
2.1 دورها التقني
تمنع انزلاق النظام إلى أداة إدارة مشاريع تقليدية، وتضمن بقاءه كبيئة تفكير حية.

2.2 المتطلبات التشغيلية
المتطلب التقني	الوصف التشغيلي	الآلية التقنية
التفكير غير الخطي	السماح بأفكار مبتورة أو متناقضة	عقد بيانية (Nodes) حرة لا تشترط الانتماء لمشروع أو "حالة"
دعم الغموض	قبول القرارات المعلقة والمسارات المفتوحة	حالات مثل Unresolved, Dormant دون فرض قيود زمنية
وضع التجريب (Play)	مساحة للتجربة دون أرشفة رسمية أو نقد	Sandbox منفصل للوكلاء بقواعد مخففة (Low-Constraint Mode)
الحوار الذاتي	فصل المذكرات الشخصية عن مدخلات الوكلاء	وسوم Private Thought لا تدخل في تحليل الوكلاء إلا بطلب صريح
دعم الامتناع	جعل "عدم الفعل" خياراً نظامياً معتبراً	خيار Explicit Non-Action كقرار نهائي موثق الأسباب
الجمال والهدوء	واجهة تقلل الضوضاء البصرية والذهنية	واجهة Minimalist، غياب الإشعارات، ونمط التركيز العميق
3. النموذج التقني (Data Model & Architecture)
3.1 نموذج البيانات (ERD)
الجداول الأساسية:

workspaces - تحتوي كل شيء (Project / Sandbox / Journal)

nodes - العقدة العامة (Idea/Proposal/Decision/Conflict/Experiment...)

node_versions - نسخ محتوى العقدة

edges - روابط بين العقد (Graph داخل Postgres)

agents - تعريف الوكلاء

agent_runs - سجلات تشغيل الوكلاء

proposals - تفاصيل الاقتراح (قالب منضبط)

decisions - اعتماد القرار + Approval Token + Scope Guard

conflicts - ملف تعارض

executions - سجل التنفيذ بعد القرار

artifacts - مخرجات التنفيذ (كود/ملفات/وثائق)

events - سجل أحداث عام (Audit + Timeline)

3.2 التعدادات (Enums)
sql
workspace_mode: NORMAL, SANDBOX, JOURNAL
node_type: IDEA, PROPOSAL, DECISION, CONFLICT, EXPERIMENT, NOTE, JOURNAL_ENTRY
node_state: RAW, OPEN, IN_REVIEW, APPROVED, REJECTED, DORMANT, ARCHIVED, FROZEN
visibility: PRIVATE, SHARED
edge_type: DERIVED_FROM, EVOLVED_INTO, REFERENCES, SUPPORTS, BLOCKS, CONFLICTS_WITH, QUESTIONS
agent_run_mode: NORMAL, SANDBOX, RED_TEAM
3.3 الفهارس (Indexes) الأساسية
nodes: (workspace_id, updated_at desc), (workspace_id, type, state)

edges: (from_node_id), (to_node_id), (type, from_node_id)

agent_runs: (node_id, created_at desc), (agent_id, created_at desc)

events: (ts desc), (entity_type, entity_id, ts desc)

4. واجهات البرمجة (API Specification)
4.1 المسارات الأساسية
text
POST    /workspaces           # إنشاء مساحة عمل
GET     /workspaces           # قائمة المساحات
POST    /nodes               # إنشاء عقدة (فكرة/ملاحظة/مذكرة)
GET     /nodes               # قائمة العقد مع فلاتر
POST    /agents/{agentKey}/runs # تشغيل وكيل على عقدة
POST    /conflicts/detect    # كشف تعارضات
POST    /decisions/approve   # اعتماد قرار
POST    /execute             # تنفيذ قرار
GET     /timeline            # استعلام السجل الزمني
GET     /metrics/dashboard   # لوحة المؤشرات
4.2 نماذج البيانات (Schemas)
yaml
NodeCreate:
  type: object
  required: [workspace_id, type, title]
  properties:
    workspace_id: {type: string, format: uuid}
    type: {enum: [IDEA, PROPOSAL, DECISION, ...]}
    title: {type: string}
    content_md: {type: string}

DecisionApproveRequest:
  type: object
  required: [proposal_node_id, approved_by]
  properties:
    proposal_node_id: {type: string, format: uuid}
    approved_by: {type: string}
    approval_token: {type: string}
5. خطة العمل (MVP Backlog)
5.1 Epic A: Workspace + Knowledge Core
A1: إنشاء مساحة عمل (Normal/Sandbox/Journal)

A2: إنشاء Node حر من أي نوع

A3: نسخ المحتوى (Versions)

A4: روابط بين العقد (Graph)

5.2 Epic B: Agents + Proposals
B1: سجل الوكلاء (تفعيل/تعطيل)

B2: تشغيل وكيل على Node

B3: توليد Proposal من مخرجات الوكيل

5.3 Epic C: Conflicts + Decisions
C1: كشف تعارضات (Rule-Based)

C2: اعتماد قرار + Approval Token

5.4 Epic D: Execution + Artifacts
D1: تنفيذ تجريبي (Dry-run)

D2: تنفيذ فعلي (Generate artifacts)

5.5 Epic E: Timeline + Metrics
E1: استعلام السجل الزمني

E2: لوحة مؤشرات الإدراك والكفاءة

6. تدفقات واجهة المستخدم (UX Flows)
6.1 Flow 1: "فكرة خام" تتحول إلى قرار ثم تنفيذ
إنشاء Idea في Workspace عادي

تشغيل الوكلاء (Run All Agents)

تحويل المخرجات إلى Proposal

تعبئة قالب الاقتراح (Trigger/Impact/Risks/Alternatives)

اعتماد القرار (Approve) → توليد Token

التنفيذ (Dry-run ثم Apply)

6.2 Flow 2: تعارض بين اقتراحين
النظام يكتشف تعارضاً بين Proposalين

إنشاء Conflict Case

عرض جوانب التعارض وأبعاده

خيارات المستخدم: تأجيل، طلب رأي وكيل إضافي، فتح Sandbox للتجربة

حسم التعارض يدوياً

6.3 Flow 3: وضع اللعب (Sandbox Mode)
فتح Workspace من نوع SANDBOX

كتابة أفكار عشوائية/متطرفة

تشغيل وكلاء بقواعد مخففة (Red Team)

خيار ترقية الأفكار إلى Workspace عادي أو حذفها تلقائياً

6.4 Flow 4: الحوار الذاتي (Journal Mode)
فتح Workspace من نوع JOURNAL

كتابة مذكرات وشكوك شخصية

النظام لا يحلل تلقائياً

التحليل يتم فقط بطلب صريح (Ask Agent on Journal)

7. مؤشرات الأداء (KPIs)
7.1 مؤشرات إدراكية (Cognitive KPIs)
وضوح القرار (Decision Clarity): نسبة القرارات المكتملة العناصر ≥ 0.80

كثافة التعارض الصحي (Healthy Conflict Density): 0.15–0.35

مؤشر الفراغ المعرفي (Unknowns Captured Index): 1–5 لكل قرار

زمن النضج (Time-to-Decision Maturity): 0.5–3 أيام (صغير)، 3–21 يوم (بنيوي)

7.2 مؤشرات كفاءة (Efficiency KPIs)
نسبة الاقتراحات القابلة للتنفيذ (Actionable Proposal Rate): 0.35–0.60

زمن التحويل للتنفيذ (Decision-to-Execution Lead Time): <1 يوم (صغير)، 1–7 أيام (متوسط)

معدل الندم (Rollback/Regret Rate): 0.05–0.15

تقليل دوران النقاش (Loop Reduction): متوسط 1–3 دورات قبل القرار

8. خطة البناء المرحلية
المرحلة 0: تجهيز الأساس (أسبوع)
إعداد قاعدة البيانات (Postgres)

هيكلية API أساسية

واجهة مستخدم مبدئية (Workspace + Node viewer)

المرحلة 1: عقل قابل للاستخدام (2–3 أسابيع)
إنشاء وإدارة Workspaces

Nodes + Versions + Edges

Timeline وعرض الأحداث

أوضاع Sandbox وJournal

المرحلة 2: الوكلاء بشكل واقعي (3–5 أسابيع)
سجل الوكلاء (Registry)

Agent run pipeline

3 وكلاء MVP: ArchitectAgent, RiskAgent, ExplorerAgent

توليد Proposals تلقائياً

المرحلة 3: التعارض + القرار (3–5 أسابيع)
كشف التعارضات (Rule-based)

واجهة إدارة التعارضات

اعتماد القرار + Approval Token

سجل التدقيق (Audit Trail)

المرحلة 4: التنفيذ الحقيقي (4–8 أسابيع)
محرك التنفيذ (Execution Engine)

توليد Artifacts (كود/وثائق/تقارير)

رقابة الجودة بعد التنفيذ

تصدير تلقائي (ADR/Spec/Changelog)

9. النماذج الأولية (Wireframes)
9.1 شاشة لوحة العمل (Workspace Home)
text
┌──────────────────────────────────────────────────────┐
│ Extended Mind │ Workspace: Project Alpha [Mode: NORMAL] │
├──────────────────────────────────────────────────────┤
│ [+ New Idea] [+ New Note] [+ Journal Entry] [Search...]│
├──────────────────────────────────────────────────────┤
│ Left Panel (Graph/Tree) │ Main Panel                  │
│ ┌─────────────────────────┐ │ ┌──────────────────┐   │
│ │ Ideas                   │ │ │ Selected Node    │   │
│ │ - API redesign (OPEN)   │ │ │ Title            │   │
│ │ - Printing rules (DORM) │ │ │ Content (MD)     │   │
│ └─────────────────────────┘ │ │ [Run Agents]     │   │
│                             │ └──────────────────┘   │
└──────────────────────────────────────────────────────┘
9.2 شاشة قالب الاقتراح (Proposal Form)
text
┌──────────────────────────────────────────────────────┐
│ Proposal (from Idea #...)                            │
├──────────────────────────────────────────────────────┤
│ Trigger: [........................................]  │
│ Impact:  [........................................]  │
│ Risks:   [+ Add Risk] (likelihood/severity/mitigation)│
│ Alternatives: [+ Add Alt] (tradeoffs/why not)        │
│ Effort: (S/M/L) hours: [min] - [max]                 │
│ Execution plan: [................................]   │
├──────────────────────────────────────────────────────┤
│ [Save Draft] [Submit for Decision]                   │
└──────────────────────────────────────────────────────┘
9.3 شاشة التعارض (Conflict Case)
text
┌──────────────────────────────────────────────────────┐
│ Conflict Case: "Perf vs Security" Status: OPEN       │
├──────────────────────────────────────────────────────┤
│ Left Proposal (Performance) │ Right (Security)       │
│ ┌──────────────────────────┐ │ ┌──────────────────┐ │
│ │ Claims: reduce latency   │ │ │ Claims: add checks│ │
│ │ Cost: medium             │ │ │ Cost: high       │ │
│ └──────────────────────────┘ │ └──────────────────┘ │
├──────────────────────────────────────────────────────┤
│ System summary: what differs + what's shared         │
│ Dimensions: [performance] [security] [maintainability]│
├──────────────────────────────────────────────────────┤
│ [Ask another Agent] [Open Experiment Sandbox]        │
│ [Resolve: Choose Left] [Choose Right] [Defer]        │
└──────────────────────────────────────────────────────┘
9.4 شاشة لوحة المؤشرات (Metrics Dashboard)
text
┌──────────────────────────────────────────────────────┐
│ Metrics Dashboard                                    │
├──────────────────────────────────────────────────────┤
│ Cognitive KPIs:                                      │
│ - Decision Clarity: 0.82 (target ≥0.80)             │
│ - Healthy Conflict Density: 0.21 (target 0.15–0.35) │
│ - Unknowns Captured Index: 2.4                      │
│ Efficiency KPIs:                                     │
│ - Decision→Execution Lead Time: 1.8 days            │
│ - Rollback/Regret Rate: 0.09                        │
└──────────────────────────────────────────────────────┘
10. الملاحق
10.1 نماذج بيانات مفصلية (JSON Examples)
json
// Node Creation
{
  "workspace_id": "uuid",
  "type": "IDEA",
  "title": "إعادة تصميم واجهة برمجة التطبيقات",
  "content_md": "## المشكلة\nالواجهة الحالية معقدة...",
  "visibility": "SHARED"
}

// Agent Run Output
{
  "agent_key": "architect",
  "node_id": "uuid",
  "output": {
    "recommendations": ["استخدام REST", "إضافة versioning"],
    "risks": ["كسر التوافق"],
    "alternatives": ["GraphQL", "gRPC"]
  }
}
10.2 قائمة الوكلاء المقترحة (Agent Registry)
وكيل المعمارية (Architect): يراقب تماسك الهيكل وقابلية التوسع

وكيل الجودة (Clean Code): يراقب التبسيط وعدم التكرار

وكيل الأمان (Security): يحلل مخاطر الثغرات وتسريب البيانات

وكيل الأداء (Performance): يقيس السرعة واستهلاك الموارد

وكيل الوثائق (Chronicler): يجمع السياق ويحوله إلى تاريخ تقني

وكيل التكلفة (Feasibility): يقدّر الجهد والوقت والتعقيد

وكيل الاستكشاف (Explorer): يقدم أفكارًا بديلة/متمردة

وكيل الفريق الأحمر (Red Team): يتعمد النقد والهدم للتقييم

📌 ملاحظة: هذه الوثيقة قابلة للتعديل والتوسع، وتمثل الإصدار 0.1 من مواصفات نظام العقل الممتد.